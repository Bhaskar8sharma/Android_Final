package com.example.cool.bhaskarsharma_comp304finallabtest_003;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AccountActivity extends AppCompatActivity {

    AccountManager accountManager;
    EditText accountNumber, accountHolderName, balanceAmount, bankName;
    Button addAccounts, displayAccountDetails, accountService;

private final static String TABLE_NAME = "Account";

    private static final String tableCreatorString =
            "CREATE TABLE "+ TABLE_NAME + " (accountNo INTEGER PRIMARY KEY, accountHolderName" +
                    " TEXT,balanceAmount REAL, bankName TEXT);";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accountNumber = findViewById(R.id.accountNo);
        accountHolderName = findViewById(R.id.accountHolderName);
        balanceAmount = findViewById(R.id.balanceAmount);
        bankName = findViewById(R.id.bankName);

        addAccounts = findViewById(R.id.addAccounts);
                displayAccountDetails= findViewById(R.id.displayAccountDetails);
        accountService= findViewById(R.id.accountService);
        try
        {
            accountManager = new AccountManager(this);
            accountManager.dbInitialize(TABLE_NAME, tableCreatorString);
        }
        catch (Exception e)
        {
            Toast.makeText(AccountActivity.this,
                    e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ",e.getMessage());
        }
    }
    public void addAccount(View view)
    {
        int accNo = Integer.parseInt(accountNumber.getText().toString());

        ContentValues contentValues = new ContentValues();
        contentValues.put("accountNo","12345678");
        contentValues.put("accountHolderName","Sharma");
        contentValues.put("balanceAmount","1234");
        contentValues.put("bankName","RBC");

        try {
            accountManager.addRow(contentValues);
            Toast.makeText(AccountActivity.this,
                    "Task Added", Toast.LENGTH_SHORT).show();
        }
        catch(Exception exception)
        {
            Toast.makeText(AccountActivity.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ",exception.getMessage());

        }
    }
    public void details(View view)
    {
        try {
            Account acc = accountManager.getAccountById(accountNumber.getText().toString(), "12345678");

            Toast.makeText(AccountActivity.this,
                    acc.getAccountNo() + " " + acc.getAccountHolderName() + " " + acc.getBalanceAmount() + " " + acc.getBankName(), Toast.LENGTH_LONG).show();
        }
        catch (Exception exception)
        {
            Toast.makeText(AccountActivity.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ",exception.getMessage());

        }
    }
    public void accService(View view)
    {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_ALTERNATIVE);
        startActivity(intent);
    }
    }

