package com.example.cool.bhaskarsharma_comp304finallabtest_003;
public class Account {
    int AccountNumber;
    String accountHolderName;
    double balanceAmount;
    String bankName;

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public double getBalanceAmount() {

        return balanceAmount;
    }

    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public String getAccountHolderName() {

        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public int getAccountNo() {

        return AccountNumber;
    }

    public void setAccountNumber(int AccountNumber) {
        AccountNumber = AccountNumber;
    }

    public Account(int AccountNumber,
                   String accountHolderName,
                   double balanceAmount,
                   String bankName )
    {
        this.AccountNumber = AccountNumber;
        this.accountHolderName = accountHolderName;
        this.balanceAmount = balanceAmount;
        this.bankName = bankName;
    }

}
